/*$Id: area.h,v 1.2 2002/02/13 12:30:57 root Exp $
*/
#ifndef _AREA_
#define _AREA_

/*
 *  these defines are to make differentiation easier
 */

#define MIDGAARD  0
#define NEWTHALOS 1

#define MORDILNIA 2
#define CARAVAN   3
#define TROGCAVES 4
#define OUTPOST   5
#define PRYDAIN   6

#endif
