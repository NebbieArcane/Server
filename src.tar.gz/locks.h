int glock(int fd,int timeout);
int gunlock(int fd);
