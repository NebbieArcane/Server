/*$Id: gilde.h,v 1.2 2002/02/13 12:30:58 root Exp $
*/
#if !defined( _GILDE_H )
#define _GILDE_H

void BootGuilds( void );

#endif
