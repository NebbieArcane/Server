/*$Id: version.h,v 1.2 2002/02/13 12:30:59 root Exp $
*/
/*AlarMUD*/
/*Prototype */
#ifndef _VERSION_
#define _VERSION_ 1
char *version(void);
char *release(void);
char *compilazione(void);
#endif


