/*$Id: debug.h,v 1.2 2002/02/13 12:30:57 root Exp $
*/

#define __DEBUG
