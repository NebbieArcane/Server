/*$Id: poly.h,v 1.2 2002/02/13 12:30:58 root Exp $
*/

/*
**  just for polymorph spell(s)
*/

struct PolyType {
  char name[20];
  int  level;
  int  number;
};
