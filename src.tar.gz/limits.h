/*$Id: limits.h,v 1.2 2002/02/13 12:30:58 root Exp $
*/

struct title_type
{
        char *title_m;
        char *title_f;
        int exp;
};
